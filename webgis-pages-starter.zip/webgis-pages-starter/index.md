---
layout: home
title: Beranda
author_profile: false
---

Selamat datang. Ini situs statis rasa WordPress.  
• Untuk menulis artikel baru, buat file di folder `_posts`.  
• Untuk melihat peta, buka **/map/** atau klik tautan di menu (kalau ada).