---
layout: single
title: "Postingan Pertama"
date: 2025-09-23
categories: blog
tags: [info]
---

Ini contoh artikel. Edit file ini atau buat yang baru di folder `_posts/`.
Format nama file: `YYYY-MM-DD-judul.md`.