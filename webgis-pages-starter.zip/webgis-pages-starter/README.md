# Starter: GitHub Pages + Jekyll (Minimal Mistakes) + Leaflet

Langkah cepat:
1) Upload semua file ini ke repo GitHub publik.
2) Settings -> Pages -> Deploy from a branch (main / root).
3) Buka halaman /map/ untuk melihat peta.
4) Edit `_config.yml` dan isi `url` dengan domainmu setelah custom domain aktif.